import { useStateContext } from '../contexts/ContextProvider'
import { Link, Navigate } from 'react-router-dom'
import axiosClient from '../axios.js'
import { useEffect } from 'react'

export default function DefaultLayout() {
  const { currentUser, userToken, setCurrentUser, setUserToken } = useStateContext()

  if (!userToken) {
    return <Navigate to='/login'/>
  }

  const logout = (ev) => {
    ev.preventDefault()
    axiosClient.post('/logout')
    .then(() => {
      setCurrentUser({})
      setUserToken(null)
    })
  }

  useEffect(() => {
    axiosClient.get('/me')
      .then(({ data }) => {
        setCurrentUser(data);
      })
      .catch(() => {
        setUserToken(null);
      });
  }, [userToken]);

  return (
    <div>
      {userToken ? (
        <>
          <p>Token: {userToken}</p>
          <p>Name: {currentUser?.name || 'Loading...'}</p>
          <p>Email: {currentUser?.email || 'Loading...'}</p>
          <a href="#" onClick={(ev) => logout(ev)}>Logout</a>
        </>
      ) : (
        <Navigate to="/login" />
      )}
    </div>
  )
}
